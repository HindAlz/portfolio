"""Synthetic-vector checks; no camera, face data, or model downloads needed."""

import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from attendance import best_match, load_database, record_observation, attendance_rows


class AttendanceTests(unittest.TestCase):
    def test_similarity_is_scale_invariant_and_unknown_is_rejected(self):
        references = {"sample_a": [1, 0], "sample_b": [0, 1]}
        self.assertEqual(best_match([5, 0], references)[0], "sample_a")
        self.assertIsNone(best_match([-1, -1], references)[0])

    def test_threshold_is_strict(self):
        self.assertIsNone(best_match([1, 0], {"sample": [1, 0]}, threshold=1)[0])

    def test_invalid_vectors_are_rejected(self):
        for vector in ([0, 0], [float("nan"), 1], [1, 2, 3]):
            with self.assertRaises(ValueError):
                best_match(vector, {"sample": [1, 0]})
        with self.assertRaises(ValueError):
            best_match([1, 0], {})

    def test_observations_are_deduplicated_and_report_counts_preserved(self):
        history = {}
        record_observation(history, [
            {"label": "a", "score": 0.7}, {"label": "a", "score": 0.9},
            {"label": None, "score": 0.2},
        ])
        self.assertEqual(history, {"a": [0.9]})
        rows = attendance_rows({"a": [], "b": []}, history, minimum=2)
        self.assertEqual(rows[0]["status"], "Not confirmed")
        record_observation(history, [{"label": "a", "score": 0.8}])
        rows = attendance_rows({"a": [], "b": []}, history, minimum=2)
        self.assertEqual(rows[0]["status"], "Present")
        self.assertEqual(rows[0]["observations"], 2)
        self.assertEqual(rows[1]["observations"], 0)

    def test_database_round_trip_and_model_validation(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "references.json"
            data = {"model": "Facenet", "detector": "mtcnn", "references": {"sample": np.ones(128).tolist()}}
            path.write_text(json.dumps(data), encoding="utf-8")
            self.assertEqual(load_database(path)["sample"].size, 128)
            data["model"] = "ArcFace"
            path.write_text(json.dumps(data), encoding="utf-8")
            with self.assertRaises(ValueError):
                load_database(path)


if __name__ == "__main__":
    unittest.main()
