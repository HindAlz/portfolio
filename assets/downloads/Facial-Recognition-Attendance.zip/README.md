# Facial Recognition Attendance

A local computer-vision coursework prototype that compares detected faces with an enrolled reference database and produces an attendance CSV.

Developed for **Introduction to Artificial Intelligence, Khalifa University, Spring 2025**. This repository organizes the implementation described in the team's report dated **30 April 2025** into readable Python files.

## Team

- Hind Alzaabi
- Shouq Alhammadi
- Nour Elalfy
- Maryam Alhmoudi

Course instructor: Dr. Naoufel Werghi.

## What it does

- Builds one averaged FaceNet embedding for each enrolled participant.
- Detects faces with an OpenCV Haar Cascade, then uses DeepFace's FaceNet model with the MTCNN backend on face crops.
- Matches embeddings using cosine similarity and a configurable threshold, initially **0.5**.
- Checks an uploaded image or a browser-camera snapshot through Streamlit.
- Processes a folder of images or a continuous local webcam stream through the command line.
- Exports observations and attendance decisions to CSV.

This uses pretrained models; it does not train a new face-recognition network. FaceNet is the recognition model, while Haar Cascade and MTCNN perform detection-related work. The report's introductory references to RetinaFace and ArcFace describe other explored configurations; this version follows the FaceNet implementation in its methodology and code sections.

## Setup

Use **Python 3.11** and run these commands from the extracted repository folder:

```bash
python -m venv .venv
```

Activate the environment on Windows PowerShell:

```powershell
.venv\Scripts\Activate.ps1
```

Or on macOS/Linux:

```bash
source .venv/bin/activate
```

Install dependencies:

```bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

The original report did not record package versions. The requirements specify a suggested TensorFlow-based environment, not the original experimental environment. Installation and full neural-model execution have not been verified for this reconstructed package. The first DeepFace call needs internet access to download model weights; startup can take time.

## 1. Prepare enrollment images

Create **`data/enrollment/`**, with one subfolder per consenting participant. The folder name becomes their label. For example:

| Path | Contents |
| --- | --- |
| `data/enrollment/participant_01/` | Several clear JPG/PNG images of participant 01 |
| `data/enrollment/participant_02/` | Several clear JPG/PNG images of participant 02 |
| `data/queries/` | Separate images to check after enrollment |

Each enrollment image must contain exactly one detected face. Use separate enrollment and evaluation images. Real participant images, face embeddings, and attendance records are not distributed in this repository and are excluded by `.gitignore`.

## 2. Build the reference database

```bash
python attendance.py enroll data/enrollment
```

The script averages valid embeddings per participant and writes **`embeddings/facenet.json`**. It reports skipped images and does not create a database if no usable faces are found.

To deliberately replace an existing database:

```bash
python attendance.py enroll data/enrollment --overwrite
```

## 3. Open the interface

```bash
python -m streamlit run app.py
```

Choose **Upload image** or **Camera snapshot**, then select **Check this image**. The interface shows detections and a downloadable report for that image only. It does not silently accumulate results from earlier uploads.

## Other ways to run

Check a single image:

```bash
python attendance.py image data/queries/example.jpg
```

Check a folder, counting each participant at most once per image:

```bash
python attendance.py batch data/queries --output reports/batch.csv
```

Run the local computer's webcam, processing every fifth frame:

```bash
python attendance.py webcam --every 5 --minimum 5 --output reports/webcam.csv
```

Press **Q in the OpenCV preview window** to stop and save the report. This mode requires a local desktop display and camera access; it does not access a remote website visitor's webcam. Change `--camera 0` to another index if needed.

Use `--threshold 0.6` to change the matching cutoff or `--database path/to/facenet.json` for another reference database. `python attendance.py --help` lists the modes.

## How to interpret the output

The similarity score is a cosine similarity, **not a confidence percentage**. A match must score strictly above the configured threshold. Unmatched faces are labeled **Unknown**.

An image check needs one observation for a **Present** result. Webcam mode defaults to five processed-frame observations. **Not confirmed** means insufficient observations, not proof that a person was absent. Consecutive frames are correlated; five observations do not establish five independent confirmations.

## Results recorded in the original report

| Report scenario | Recorded counts | Interpretation |
| --- | --- | --- |
| Everyone present | 36 true positives, 6 false negatives, no false positives, out of 42 queries | Reported recall 85.71%; this all-present subset does not measure specificity |
| Absence-focused test | 77 false positives and 523 true negatives out of 600 negative cases | True-negative rate 87.17%; not overall classification accuracy |

These are historical report results and were **not reproduced with this package**. The report does not provide enough detail or evaluation data for an independent reconstruction of the full experiment. Dataset size, threshold choices, lighting, pose, and enrollment coverage limit generalization. False attendance matches occurred in the original tests.

## Organization and changes from the report

| File | Purpose |
| --- | --- |
| `attendance.py` | Enrollment, cosine matching, image/batch/webcam processing, and CSV output |
| `app.py` | Streamlit image and camera-snapshot interface |
| `requirements.txt` | Suggested dependency environment |
| `tests/test_attendance.py` | Synthetic-vector and report-logic tests |

The original code was embedded in a PDF with broken indentation and notebook-specific paths. This version replaces those paths with command-line arguments, uses a JSON reference format instead of CSV-serialized NumPy arrays, checks invalid embeddings, keeps OpenCV images in BGR format, avoids duplicate counts within one observation, and closes the camera reliably. Enrollment explicitly uses MTCNN and requires one detected face. Augmentation/model-comparison experiments are not included in this cleaned baseline.

Continuous webcam processing is a separate OpenCV command, rather than the report's long-running Streamlit loop. The browser interface uses discrete snapshots. These changes make the code easier to inspect and run but mean this is an **organized adaptation**, not a byte-for-byte reproduction or a verified recreation of the historical results.

## Checks

The logic tests need only NumPy:

```bash
python -m unittest discover -s tests -v
```

They cover similarity, threshold rejection, invalid vectors, per-observation deduplication, report counts, and database validation. They do not measure recognition accuracy or test camera/model execution.

## Scope and credits

Use this as a small, consent-based local demonstration. It has no liveness detection or anti-spoofing checks and is not a validated attendance or access-control system. Manually review its outputs. Do not upload participants' images, embeddings, or attendance files to a public repository.

Built with [DeepFace](https://github.com/serengil/deepface), [OpenCV](https://opencv.org/), [TensorFlow](https://www.tensorflow.org/), and [Streamlit](https://streamlit.io/). The underlying models and libraries retain their own licensing and attribution. No license grant for the team's original work is assumed here.
