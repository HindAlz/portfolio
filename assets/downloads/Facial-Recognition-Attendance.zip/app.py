"""Streamlit interface for one uploaded image or browser-camera snapshot."""

import csv
import io
from pathlib import Path

import cv2
import numpy as np
import streamlit as st

from attendance import (
    DEFAULT_DATABASE, annotate, attendance_rows, load_database,
    recognize, record_observation,
)


def main():
    st.set_page_config(page_title="Face Recognition Attendance", layout="wide")
    st.title("Face Recognition Attendance")
    st.caption("Coursework prototype · Local reference database · FaceNet similarity matching")

    database = st.sidebar.text_input("Reference database", str(DEFAULT_DATABASE))
    threshold = st.sidebar.slider("Cosine similarity threshold", -1.0, 1.0, 0.5, 0.01)
    st.sidebar.caption("Similarity is not a probability. Use images from consenting participants.")
    try:
        references = load_database(Path(database))
    except (ValueError, OSError) as error:
        st.info("Create your reference database first: python attendance.py enroll data/enrollment")
        st.caption(str(error))
        return

    mode = st.radio("Image source", ["Upload image", "Camera snapshot"], horizontal=True)
    if mode == "Upload image":
        uploaded = st.file_uploader("Choose a JPG or PNG", type=["jpg", "jpeg", "png"])
    else:
        uploaded = st.camera_input("Take a photo")
    st.caption("For continuous local video, use: python attendance.py webcam")

    if uploaded is None:
        return
    image = cv2.imdecode(np.frombuffer(uploaded.getvalue(), dtype=np.uint8), cv2.IMREAD_COLOR)
    if image is None:
        st.error("This file could not be decoded as an image.")
        return

    if st.button("Check this image", type="primary"):
        try:
            with st.spinner("Comparing detected faces with enrolled references…"):
                detections = recognize(image, references, threshold)
            history = {}
            record_observation(history, detections)
            rows = attendance_rows(references, history, minimum=1)
            st.image(annotate(image, detections), channels="BGR", caption="Current image only")
            st.dataframe(rows, use_container_width=True)
            if not detections:
                st.info("No faces were detected in this image.")
            buffer = io.StringIO(newline="")
            writer = csv.DictWriter(buffer, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
            st.download_button("Download attendance CSV", buffer.getvalue(), "attendance.csv", "text/csv")
        except Exception as error:
            st.error(f"Image processing failed: {error}")


if __name__ == "__main__":
    main()
