"""Local FaceNet attendance prototype, organized from the Spring 2025 report.

Run `python attendance.py --help` for enrollment, image, batch, and webcam modes.
DeepFace and OpenCV are loaded only when image processing is requested.
"""

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np


MODEL = "Facenet"
DETECTOR = "mtcnn"
DEFAULT_DATABASE = Path("embeddings/facenet.json")
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png"}


def validated_vector(value):
    """Reject malformed references instead of returning invalid similarities."""
    vector = np.asarray(value, dtype=float)
    if vector.ndim != 1 or vector.size == 0:
        raise ValueError("An embedding must be a nonempty one-dimensional vector.")
    if not np.isfinite(vector).all() or np.linalg.norm(vector) == 0:
        raise ValueError("An embedding must be finite and have a nonzero norm.")
    return vector


def best_match(query, references, threshold=0.5):
    """Return a label only when its cosine similarity exceeds the threshold.

    Similarity is not a calibrated probability or confidence percentage.
    """
    if not -1 <= threshold <= 1:
        raise ValueError("Similarity threshold must be between -1 and 1.")
    query = validated_vector(query)
    best_label, best_score = None, -float("inf")
    for label, reference in references.items():
        reference = validated_vector(reference)
        if reference.shape != query.shape:
            raise ValueError("Embedding dimensions differ; rebuild the database.")
        score = float(np.dot(query, reference) / (
            np.linalg.norm(query) * np.linalg.norm(reference)
        ))
        score = float(np.clip(score, -1, 1))
        if score > best_score:
            best_label, best_score = label, score
    if best_label is None:
        raise ValueError("The reference database is empty.")
    return (best_label if best_score > threshold else None), best_score


def load_database(path):
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if data.get("model") != MODEL or data.get("detector") != DETECTOR:
        raise ValueError("Database model or detector differs; run enroll again.")
    references = {
        label: validated_vector(vector)
        for label, vector in data.get("references", {}).items()
    }
    if not references:
        raise ValueError("No enrolled people were found in the database.")
    if any(vector.size != 128 for vector in references.values()):
        raise ValueError("This project expects 128-dimensional FaceNet embeddings.")
    return references


def image_paths(directory):
    directory = Path(directory)
    if not directory.is_dir():
        raise ValueError(f"Image directory does not exist: {directory}")
    return sorted(
        path for path in directory.iterdir()
        if path.is_file() and path.suffix.lower() in IMAGE_EXTENSIONS
    )


def read_image(path):
    import cv2

    # imdecode also supports Windows paths containing non-ASCII characters.
    image = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError(f"Cannot read image: {path}")
    return image


def enroll(directory, output, overwrite=False):
    """Average face embeddings from one folder per consenting participant."""
    from deepface import DeepFace

    directory, output = Path(directory), Path(output)
    if not directory.is_dir():
        raise ValueError(f"Enrollment directory does not exist: {directory}")
    if output.exists() and not overwrite:
        raise ValueError(f"{output} already exists. Use --overwrite to replace it.")
    references = {}
    for person_folder in sorted(directory.iterdir()):
        if not person_folder.is_dir():
            continue
        vectors = []
        for path in image_paths(person_folder):
            try:
                # OpenCV arrays are BGR; pass that format directly to DeepFace.
                faces = DeepFace.represent(
                    img_path=read_image(path), model_name=MODEL,
                    detector_backend=DETECTOR, enforce_detection=True,
                )
                if len(faces) != 1:
                    print(f"Skipped {path.name}: enrollment needs exactly one face.")
                    continue
                vectors.append(validated_vector(faces[0]["embedding"]))
            except (ValueError, OSError) as error:
                print(f"Skipped {path.name}: {error}")
        if vectors:
            mean = validated_vector(np.mean(vectors, axis=0))
            references[person_folder.name] = mean.tolist()
            print(f"Enrolled {person_folder.name}: {len(vectors)} images")
        else:
            print(f"No usable images for {person_folder.name}.")
    if not references:
        raise ValueError("No usable enrollment images; no database was written.")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps({
        "model": MODEL, "detector": DETECTOR,
        "aggregation": "mean", "references": references,
    }, indent=2), encoding="utf-8")
    print(f"Saved local reference database: {output}")


def recognize(image, references, threshold=0.5):
    """Localize faces with Haar Cascade, then compare FaceNet embeddings."""
    import cv2
    from deepface import DeepFace

    cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    cascade = cv2.CascadeClassifier(cascade_path)
    if cascade.empty():
        raise RuntimeError("OpenCV could not load its Haar Cascade classifier.")
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    boxes = cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)
    detections = []
    for x, y, width, height in boxes:
        crop = image[y:y + height, x:x + width]
        if crop.size == 0:
            continue
        results = DeepFace.represent(
            img_path=crop, model_name=MODEL, detector_backend=DETECTOR,
            enforce_detection=False,
        )
        if not results:
            continue
        label, score = best_match(results[0]["embedding"], references, threshold)
        detections.append({
            "label": label, "score": score,
            "box": tuple(int(value) for value in (x, y, width, height)),
        })
    return detections


def record_observation(history, detections):
    """Count each person at most once per image or processed video frame."""
    scores = {}
    for detection in detections:
        label = detection["label"]
        if label is not None:
            scores[label] = max(scores.get(label, -1), detection["score"])
    for label, score in scores.items():
        history.setdefault(label, []).append(score)


def attendance_rows(references, history, minimum=1):
    if minimum < 1:
        raise ValueError("Minimum observations must be at least one.")
    rows = []
    for label in sorted(references):
        scores = history.get(label, [])
        rows.append({
            "label": label,
            "status": "Present" if len(scores) >= minimum else "Not confirmed",
            "observations": len(scores),
            "mean_similarity": round(float(np.mean(scores)), 4) if scores else "",
        })
    return rows


def save_report(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=[
            "label", "status", "observations", "mean_similarity",
        ])
        writer.writeheader()
        writer.writerows(rows)


def annotate(image, detections):
    import cv2

    annotated = image.copy()
    for detection in detections:
        x, y, width, height = detection["box"]
        label = detection["label"] or "Unknown"
        color = (0, 180, 0) if detection["label"] else (0, 165, 255)
        cv2.rectangle(annotated, (x, y), (x + width, y + height), color, 2)
        cv2.putText(
            annotated, f"{label} ({detection['score']:.2f})", (x, max(y - 8, 20)),
            cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1,
        )
    return annotated


def webcam(references, threshold, camera, every):
    """Use the local computer's camera; press Q in the preview to finish."""
    import cv2

    if every < 1:
        raise ValueError("Frame interval must be at least one.")
    capture = cv2.VideoCapture(camera)
    history = defaultdict(list)
    frame_number = 0
    detections = []
    try:
        if not capture.isOpened():
            raise RuntimeError("Camera unavailable. Check permissions and camera index.")
        while True:
            ok, frame = capture.read()
            if not ok:
                break
            if frame_number % every == 0:
                detections = recognize(frame, references, threshold)
                record_observation(history, detections)
            frame_number += 1
            cv2.imshow("Attendance demo - press Q to finish", annotate(frame, detections))
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break
    finally:
        capture.release()
        cv2.destroyAllWindows()
    return history


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    enrollment = commands.add_parser("enroll", help="Build local averaged embeddings")
    enrollment.add_argument("directory", type=Path)
    enrollment.add_argument("--output", type=Path, default=DEFAULT_DATABASE)
    enrollment.add_argument("--overwrite", action="store_true")
    for mode in ("image", "batch", "webcam"):
        command = commands.add_parser(mode)
        if mode != "webcam":
            command.add_argument("input", type=Path)
        command.add_argument("--database", type=Path, default=DEFAULT_DATABASE)
        command.add_argument("--threshold", type=float, default=0.5)
        command.add_argument("--output", type=Path, default=Path("reports/attendance.csv"))
        command.add_argument("--minimum", type=int, default=5 if mode == "webcam" else 1)
        if mode == "webcam":
            command.add_argument("--camera", type=int, default=0)
            command.add_argument("--every", type=int, default=5)
    args = parser.parse_args()
    try:
        if args.command == "enroll":
            enroll(args.directory, args.output, args.overwrite)
            return
        if not -1 <= args.threshold <= 1 or args.minimum < 1:
            raise ValueError("Use a threshold in [-1, 1] and a positive minimum.")
        references = load_database(args.database)
        if args.command == "webcam":
            history = webcam(references, args.threshold, args.camera, args.every)
        else:
            paths = [args.input] if args.command == "image" else image_paths(args.input)
            if not paths:
                raise ValueError("No JPG or PNG images found.")
            history = defaultdict(list)
            for path in paths:
                detections = recognize(read_image(path), references, args.threshold)
                record_observation(history, detections)
                names = sorted({d['label'] for d in detections if d['label']})
                print(f"{path.name}: {', '.join(names) if names else 'No enrolled person recognized'}")
        rows = attendance_rows(references, history, args.minimum)
        save_report(args.output, rows)
        for row in rows:
            print(f"{row['label']}: {row['status']} ({row['observations']} observations)")
        print(f"Saved report: {args.output}")
    except (ValueError, OSError, RuntimeError, ImportError) as error:
        parser.exit(1, f"Error: {error}\n")


if __name__ == "__main__":
    main()
